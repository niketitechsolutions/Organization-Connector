package com.itech;

import javax.swing.*;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

/**
 * Created by Niket Doshi 
 */
public class Config {
    private static Properties prop;
    private String configFileName;
    static List<String> webApps = new ArrayList<String>();
    public Config(String fileName) {
        configFileName = fileName;
        try {
            prop = new Properties();
            InputStream is = new FileInputStream(configFileName);
            prop.load(is);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            Enumeration properties = prop.propertyNames();
            while (properties.hasMoreElements()) {
                String key = (String) properties.nextElement();
                if (key.startsWith("webApp.")) {
                    String data=prop.getProperty(key);
                    try {
                        data = data + "-" + Config.getProperty("webAppConnection." + key.substring(key.indexOf(".") + 1));
                    }catch(Exception e){System.out.println("Error : "+e.getMessage());}
                    webApps.add(data);
                }
            }
        }catch(Exception e){System.out.println("Error : "+e.getMessage());}
    }
    public static String getProperty(String key) {
        return prop.getProperty(key);
    }

    public static List getWebApps() {
        return webApps;
    }
}
