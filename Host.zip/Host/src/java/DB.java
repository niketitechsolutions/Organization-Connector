import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.StringTokenizer;

/**
 * Created by Niket Doshi on 03-03-2016.
 */
public class DB {
    Connection con;
    Statement stmt;
    ResultSet rs;
    static DB instance=null;
    public static DB getInstance()
    {
        if(instance==null)
        {
            instance=new DB();
        }
        return instance;
    }
    public DB()
    {
        connection();
    }
    public void connection()
    {
        try {
            System.out.println("in Conn");
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "");
            //authenticate("itechApp", "sec2015","sec2015");
        }catch(Exception e){
            System.out.println("Error : "+e.getMessage());
        }
    }
    public boolean authenticate(String appName,String appID,String secretID)
    {
        try{
            System.out.println(appName+":"+appID+":"+secretID);
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery("select * from launcher where appName='"+appName+"' and appID='"+appID+"' and secretID='"+secretID+"'");
            rs.next();
            try{
                rs.close();
                stmt.close();
                return true;
            }
            catch(Exception e) {
                rs.close();
                stmt.close();
                return false;
            }
        }catch(Exception e){
            System.out.println("Error in Authentication : "+e.getMessage());
            return false;
        }

    }
    public String getAppName(String domain)
    {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select appName from launcher where appURL='" + domain + "'");
            rs.next();
            String appName=rs.getString(1);
            rs.close();
            stmt.close();
            return appName;
        }catch(Exception e){
            System.out.println("Error in  getAppName : "+e.getMessage());
            return "";
        }
    }
    public String getWebAppName(String appName,String webAppName)
    {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select webAppName from webapps where appName='" + appName + "' AND webAppName='"+webAppName+"'");
            rs.next();
            webAppName=rs.getString(1);
            rs.close();
            stmt.close();
            return webAppName;
        }catch(Exception e){
            System.out.println("Error in  getAppName : "+e.getMessage());
            return "";
        }
    }
    public void addApps(String appName,String list)
    {
        System.out.println("List : "+list);
        list=list.replace("[","").replace("]","");
        StringTokenizer st=new StringTokenizer(list, ",");
        try{
            Statement stmtDelete = con.createStatement();
            String delete="delete from webapps where appName='"+appName+"'";
            stmtDelete.executeUpdate(delete);
            stmtDelete.close();
        }catch(Exception e){}
         
        while(st.hasMoreTokens())
        {
            String app=st.nextToken().trim();
            String arr[]=app.split("-");
            arr[0]=arr[0].trim();
            arr[1]=arr[1].trim();
            try{
                Statement stmtInsert = con.createStatement();
                String insert="insert into webapps values('"+appName+"','"+arr[0]+"','"+arr[1]+"')";
                stmtInsert.executeUpdate(insert);
                stmtInsert.close();
            }catch(Exception e){
                System.out.println("Error in registering webapps : "+e.getMessage());
            }
        }
    }
    
}
