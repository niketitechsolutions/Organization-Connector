
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
@WebServlet(urlPatterns = {"/Listener"})
public class Listener extends HttpServlet {
HttpServletResponse response;
    BufferedReader socketReader=null,appReader=null;
    PrintStream writter,appWritter;
    ServerSocket serverSocket;
    Socket appSocket,socket;
    DB db;
    String args=null,type=null;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        type=request.getMethod();
        System.out.println("Type : "+type);
        response.setContentType("text/html;charset=UTF-8");
        this.response=response;
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            new Config("C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Host\\src\\java\\Config.properties");
            db=DB.getInstance();
            serverSocket = new ServerSocket(Integer.parseInt(Config.getProperty("hostport")));
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Listener</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("HOST is started..<br/>Waiting for incoming connections to serve requests.");
            out.println("</body>");
            out.println("</html>");
            out.flush();
                while(true) {
                    socket = serverSocket.accept();
                    System.out.println("Connected : "+socket);
                    socketReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    System.out.println(socket.getInetAddress()+"---"+socket.getInetAddress());
                    new Thread(){public void run(){read();}}.start();
                }
        } finally {
            out.close();
        }
    }
        public void readApp()
    {
        try{
            String input=appReader.readLine();
            if(input.length()<1)
                readApp();
            PrintWriter out = response.getWriter();
            System.out.println("Response From APP : "+input);
            write(input);
            readApp();
        }catch(Exception e){System.out.println(e.getMessage());}
    }

    public void read()
    {
        try {
            String input=socketReader.readLine();
            if(input.contains("i-techsolutions.asia"))
            {
                String appName="";
                socket.setSoTimeout(2000);
                try{
                appName=socketReader.readLine();
                }catch(Exception e){
                    System.out.println("webAppName Error : "+e.getMessage());
                }
                try{
                args=socketReader.readLine();
                }catch(Exception e){
                    args=null;
                }
                appName=db.getWebAppName(db.getAppName(input),appName);
                if(appName=="" || appName==null)
                {
                    write("WEBAPP Does not exists...!!");
                }
                else
                {
                    writeApp("{\"App\":\""+appName+"\",\"Args\":\""+args+"\",\"Type\":\""+type+"\"}");    
                }
            }
            else
            {
                String apps=input.substring(input.indexOf("["));
                input=input.substring(0,input.indexOf("["));
                String appName=input.substring(0,input.indexOf(","));
                String port=input.substring(input.lastIndexOf(",")+1);
                String ids=input.substring(input.indexOf(",")+1,input.indexOf(port)-1);
                String appID=ids.substring(0,ids.indexOf(","));
                String secretID=ids.substring(ids.indexOf(",")+1);
                System.out.println(appName+":"+appID+":"+secretID);
                if(db.authenticate(appName,appID,secretID))
                {         
                    
                    db.addApps(appName,apps);
                    appSocket=socket;
// appSocket=new Socket(socket.getInetAddress(),Integer.parseInt(port),InetAddress.getByName("192.168.1.113"),7778);                    
                    System.out.println("Authentication Successful..\nNow Creating Socket Connection with APP to serve Requests..");
                    appReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    appWritter=new PrintStream(appSocket.getOutputStream());
                    System.out.println("Connection Successful with APP.\nWaiting for incoming request..");
                    PrintWriter out = response.getWriter();
                    out.println("<!DOCTYPE html>");
                    out.println("<html>");
                    out.println("<body>");
                    out.println("<br />Authentication Successful..<br/>Now Creating Socket Connection with APP to serve Requests..");
                    out.println("<br />Connection Successful with APP.<br />Waiting for incoming request..");
                    out.println("</body>");
                    out.println("</html>");
                    out.flush();
                    new Thread(){public void run(){readApp();}}.start();
                }
                else{
                    System.out.println("App Authentication Failed..");
                    PrintWriter out = response.getWriter();
                    out.println("<!DOCTYPE html>");
                    out.println("<html>");
                    out.println("<body>");
                    out.println("<br />App Authentication Failed..");
                    out.println("</body>");
                    out.println("</html>");
                    out.flush();
                    appSocket=new Socket(socket.getInetAddress(),Integer.parseInt(port));                    
                    appWritter=new PrintStream(appSocket.getOutputStream());
                    writeApp("You are not Authorized.");
                    appWritter.close();
                    appSocket.close();
                    appWritter=null;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void write(String data)
    {
        try {
            System.out.println("Sending response to Client : "+data);
            writter=new PrintStream(socket.getOutputStream());
            writter.println(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void writeApp(String data)
    {
        try {
            if(appWritter!=null) {
                System.out.println("Messaging APP : " + data);
                appWritter.println(data);
            }
            else{
                write("App is not available at the time.");
            }
        } catch (Exception e) {
            System.out.println("App is not available at the time.");
            write("App is not available at the time.");
            System.out.println("Exception in writeAPP : "+e.getMessage());
        }
    }


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
