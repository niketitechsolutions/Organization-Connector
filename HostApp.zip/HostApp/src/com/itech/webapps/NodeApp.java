package com.itech.webapps;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.URL;

/**
 * Created by Niket Doshi 
 */
public class NodeApp {
    private static NodeApp instance=null;
    public void init() {
    }

    public static NodeApp getInstance() {
        if(instance==null)
            instance=new NodeApp();
        return instance;
    }

    /*public  String resolve(String ConnectionString)
    {
       return Get(ConnectionString,null);
    }
    public  String resolve(String ConnectionString,String queryString)
    {
        return Get(ConnectionString+queryString,null);
    }*/

    public  String resolve(String ConnectionString,String args,String type)
    {
        System.out.println("Type : "+type);
        if(type.equalsIgnoreCase("GET"))
            return Get(ConnectionString,args);
        else if(type.equalsIgnoreCase("POST"))
            return Post(ConnectionString,args);
        else if(type.equalsIgnoreCase("PUT"))
            return Put(ConnectionString,args);
        else if(type.equalsIgnoreCase("DELETE"))
            return Delete(ConnectionString);
        else
            return "Unknown Method Call Received";
    }

    public String Get(String urlString,String args)
    {
        String output = "", line;
        try {
            String ip=urlString.substring(0,urlString.indexOf(":")).replace(":","");
            String port=urlString.substring(urlString.indexOf(":")).replace(":","");
            System.out.println(urlString+":"+args);
            Socket s=new Socket(ip,Integer.parseInt(port));
                System.out.println("Socket : "+s);
                PrintStream pw=new PrintStream(s.getOutputStream());
                pw.println(args);
                pw.flush();
                BufferedReader is=new BufferedReader(new InputStreamReader(s.getInputStream()));
                output=is.readLine();
                System.out.println(output);
                pw.close();
                is.close();
                s.close();
  /*
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            System.out.println(conn.getResponseCode()+":"+conn.getResponseMessage());
            try{
                if(args==null || args=="")
                    throw  new Exception();
                OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
                System.out.println("Argument : "+args);
                writer.write(args);
                writer.flush();
                writer.close();
            }catch(Exception e)
            {System.out.println("Error in write " +e.getMessage());}

               System.out.println("here");
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            while ((line = br.readLine()) != null) {
                output += line + "\n";
            }
            conn.disconnect();
*/
        }catch(Exception e){
            System.out.println("Error in GET : "+e.getMessage());
            output="Service not available at a time.";
        }
        return output;
    }

    public String Post(String urlString,String args)    {
        String output = "", line;
        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
            writer.write(args);
            writer.flush();
            writer.close();
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            while ((line = br.readLine()) != null) {
                output += line + "\n";
            }
            conn.disconnect();
        }catch(Exception e){
            System.out.println("Error in POST : "+e.getMessage());
            output="Service not available at a time.";
        }
        return output;
    }

    public String Put(String urlString,String args)    {
        String output = "", line;
        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestMethod("PUT");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
            writer.write(args);
            writer.flush();
            writer.close();
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            while ((line = br.readLine()) != null) {
                output += line + "\n";
            }
            conn.disconnect();
        }catch(Exception e){
            System.out.println("Error in PUT : "+e.getMessage());
            output="Service not available at a time.";
        }
        return output;
    }


    public String Delete(String urlString)    {
        String output = "", line;
        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestMethod("DELETE");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            while ((line = br.readLine()) != null) {
                output += line + "\n";
            }
            conn.disconnect();
        }catch(Exception e){
            System.out.println("Error in DELETE : "+e.getMessage());
            output="Service not available at a time.";
        }
        return output;
    }

}
