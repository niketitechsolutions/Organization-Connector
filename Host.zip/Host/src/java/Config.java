
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Niket Doshi
 */
public class Config {
    private static Properties prop;
    public Config(String fileName) {
        try {
            prop = new Properties();
            InputStream is = new FileInputStream(fileName);
            prop.load(is);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static String getProperty(String key) {
        return prop.getProperty(key);
    }

}
