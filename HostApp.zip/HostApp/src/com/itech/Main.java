package com.itech;
import com.itech.Config;
import com.itech.webapps.webApp;
import org.json.JSONObject;

import javax.swing.*;
import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;

/**
 * Created by Niket Doshi 
 */
public class Main {
    BufferedReader reader;
    PrintStream writter;
    Socket socket,readSocket;
    ServerSocket serverSocket;
    webApp webapp=null;
    int i=0;
    public Main()
    {
        try {
            new Config("D:\\prj\\HostApp\\src\\application.properties");
            webapp=webApp.getInstance();
            System.out.println(Integer.parseInt(Config.getProperty("hostport")));
            socket = new Socket(InetAddress.getByName(Config.getProperty("host")), Integer.parseInt(Config.getProperty("hostport")),InetAddress.getByName("192.168.1.113"),7778);
            
            //serverSocket = new ServerSocket(Integer.parseInt(Config.getProperty("localport")));
            writter = new PrintStream(socket.getOutputStream());
            String appID=Config.getProperty("app.appID");
            String secretID=Config.getProperty("app.secretID");
            byte[] appIDB=appID.getBytes();
            byte[] secretIDB=secretID.getBytes();
            MessageDigest md=MessageDigest.getInstance("md5");
            md.update(appIDB);
            appIDB=md.digest();
            md.reset();
            md.update(secretIDB);
            secretIDB=md.digest();
            write(Config.getProperty("app.name")+","+appID+","+secretID+","+Config.getProperty("localport")+Config.getWebApps());
            //readSocket = serverSocket.accept();
            readSocket = socket;
            i++;
            System.out.println("HOST attached successfully..");
            reader = new BufferedReader(new InputStreamReader(readSocket.getInputStream()));
            read();
        }catch(Exception e){
            System.out.println("Error in constructor : "+e.getMessage());}
    }

    public void write(String data)
    {
        System.out.println("Sending response to HOST : "+data);
        try {
            writter.println(data);
        } catch (Exception e) {
            System.out.println("Error in write : "+e.getMessage());
        }
        if(i>0)
            read();
    }
    public void read()
    {

        try {
            String input = reader.readLine();
            System.out.println("Received : "+input);
            if(input.startsWith("You"))
            {
                System.out.println("main : HOST : "+input);
            }
            else {
                JSONObject data=new JSONObject(input);
                System.out.println("Request received from HOST : " + input);
                String class_name="",args="",type="";
                try {
                    class_name = data.get("App").toString();
                }catch(Exception e){
                    write("WEBAPP Does not Exists..");
                }
                try {
                    args = data.get("Args").toString();
                }catch(Exception e){
                    args=null;
                }
                try {
                    type = data.get("Type").toString();
                }catch(Exception e){
                    type=null;
                }
                write(webapp.execute(class_name,args,type));
            }
        }catch(Exception e){
            System.out.println("Error in read : "+e.getMessage());}
    }

    public static void main(String[] args)
    {
        new Main();
    }
}


