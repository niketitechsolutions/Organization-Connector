package com.itech.webapps;

import com.itech.Config;


import java.util.List;

/**
 * Created by Niket Doshi 
 */
public class webApp {

    NodeApp nodeApp=null;
    static webApp instance=null;
    public webApp()

    {
        nodeApp= (NodeApp) NodeApp.getInstance();
    }

    public void init() {

    }

    public static webApp getInstance()
    {
        if(instance==null)
        {
            instance=new webApp();
        }
        return instance;
    }

    public String execute(String class_name,String args,String type)
    {
        System.out.println("Type : "+type);
        String data="";
        try {
            System.out.println("Double");
            List webApps = Config.getWebApps();
            for(int i=0;i<webApps.size();i++) {
                String value=webApps.get(i).toString();
                System.out.println("Value : "+value);
                if(value.substring(0,value.indexOf("-")).equals(class_name)) {
                    NodeApp node=new NodeApp();
                    data=node.resolve(value.substring(value.indexOf("-")+1),args,type);
                }
            }
        }catch(Exception e){
            data="Error execute two args: "+e.getMessage();
            System.out.println(data);
        }
        return data;

    }

/*    public String execute(String class_name,String arguments)
    {
        String data="";
        try {
            System.out.println("Double");
            List webApps = com.builtio.Config.getWebApps();
            for(int i=0;i<webApps.size();i++) {
                String value=webApps.get(i).toString();
                System.out.println("Value : "+value);
                if(value.substring(0,value.indexOf("-")).equals(class_name)) {
                    NodeApp node=new NodeApp();
                    data=node.resolve(value.substring(value.indexOf("-")+1),arguments);
                    Class cls = Class.forName(webAppPackageString + class_name);
                    Object obj = cls.newInstance();
                    Class[] params = new Class[2];
                    params[0] = String.class;
                    params[1] = String.class;
                    Method p_instance = cls.getMethod("getInstance");
                    Object p_instance_obj = p_instance.invoke(obj);
                    Method method = cls.getDeclaredMethod("resolve", params);
                    data = (String) method.invoke(p_instance_obj,value.substring(value.indexOf("-")+1), arguments);
              }
            }
        }catch(Exception e){
            data="Error execute two args: "+e.getMessage();
            System.out.println(data);
        }
        return data;
    }
    public String execute(String class_name) {
        String data = "";
        try {
            System.out.println("Single ");
            List webApps = com.builtio.Config.getWebApps();
            for (int i = 0; i < webApps.size(); i++) {
                String value = webApps.get(i).toString();
                if (value.substring(0, value.indexOf("-")).equals(class_name)) {
                    NodeApp node = new NodeApp();
                    data = node.resolve(value.substring(value.indexOf("-") + 1));

                    Class cls = Class.forName(webAppPackageString + class_name);
                    Object obj = cls.newInstance();
                    Class[] params = new Class[1];
                    params[0] = String.class;
                    Method p_instance = cls.getMethod("getInstance");
                    Object p_instance_obj = p_instance.invoke(obj);
                    Method method = cls.getDeclaredMethod("resolve", params);
                    data = (String) method.invoke(p_instance_obj,value.substring(value.indexOf("-")+1));


                }
            }
        } catch (Exception e) {
            data = "Error execute one args : " + e.getMessage();
            System.out.println(data);
        }
        return data;
    }
*/
}
